package com.example.itwordslearning.dto;


public class UserWrongDeleteDTO {
    private Integer userId;
    private Integer wordId;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getWordId() {
		return wordId;
	}
	public void setWordId(Integer wordId) {
		this.wordId = wordId;
	}
    
    
}
