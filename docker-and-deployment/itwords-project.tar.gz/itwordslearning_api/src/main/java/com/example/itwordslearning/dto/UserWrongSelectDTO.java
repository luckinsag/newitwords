package com.example.itwordslearning.dto;

public class UserWrongSelectDTO {
	private Integer userId;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

}
