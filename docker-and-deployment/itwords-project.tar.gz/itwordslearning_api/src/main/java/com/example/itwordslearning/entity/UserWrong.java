package com.example.itwordslearning.entity;

public class UserWrong {
	private Integer wrongId;
	private Integer sessionId;
	private Integer wordId;
	private Integer userId;

	public Integer getWrongId() {
		return wrongId;
	}

	public void setWrongId(Integer wrongId) {
		this.wrongId = wrongId;
	}

	public Integer getSessionId() {
		return sessionId;
	}

	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}

	public Integer getWordId() {
		return wordId;
	}

	public void setWordId(Integer wordId) {
		this.wordId = wordId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

}
