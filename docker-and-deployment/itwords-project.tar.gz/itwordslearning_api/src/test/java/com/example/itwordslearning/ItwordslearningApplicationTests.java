package com.example.itwordslearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItwordslearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
